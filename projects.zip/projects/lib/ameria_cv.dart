import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home:Scaffold(
          backgroundColor: Colors.brown[900],
          appBar: AppBar(
            title:const Text("C.V") ,
            centerTitle: true,
            backgroundColor: Colors.brown[700],
          ),
          body:SingleChildScrollView(
              child:Container(

                padding:const EdgeInsets.fromLTRB(30,40,30,0),

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Center(
                      child: CircleAvatar(
                          radius: 60,
                          backgroundImage: AssetImage('images/avatar2.png')),

                    ),

                    const SizedBox(

                      height: 25,
                    ),
                    const Divider(
                      height: 100,
                      color: Colors.black,
                    ),
                    Text(
                        "NAME:",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.brown[200],
                            letterSpacing: 2
                        )
                    ),
                    Text(
                        "Amira AL-moalemi",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w100,
                          color: Colors.brown[100],

                        )

                    ),
                    const SizedBox(
                      height: 20,
                    ),


                    Text(
                        "skills:",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.brown[200],
                            letterSpacing: 2

                        )
                    ),

                    Text(
                        textAlign: TextAlign.justify,
                        """Problem-solving\nTime management\nTransferable skills """,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w100,
                          color: Colors.brown[100],

                        )
                    ),
                    const SizedBox(
                      height: 20,
                    ),

                    Text(
                        "QUALIFICATIONS:",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.brown[200],
                            letterSpacing: 2

                        )
                    ),

                    Text(
                        textAlign: TextAlign.left,


                        """\nHigh IT support skills\nEnthusiasm for the job""",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w100,
                          color: Colors.brown[100],

                        )

                    ),

                    const SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: [
                        Icon(Icons.email,color: Colors.brown[100] , size: 30,),
                        const SizedBox(width: 10,),
                        Text('amier55566.gmail.com',style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold ,color: Colors.brown[100]),)
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ), Row(
                      children: [
                        Icon(Icons.phone,color: Colors.brown[100] , size: 30,),
                        const SizedBox(width: 10,),
                        Text('705894333',style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold ,color: Colors.brown[100]),)
                      ],
                    ), const SizedBox(
                      height: 20,
                    ), Row(
                      children: [
                        Icon(Icons.account_box,color: Colors.brown[100] , size: 30,),
                        const SizedBox(width: 10,),
                        Text('linkedin account:al-mualime ameria',style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold ,color: Colors.brown[100]),)
                      ],
                    )


                  ],
                ),
              )
          )
      )
  )
  );

}


