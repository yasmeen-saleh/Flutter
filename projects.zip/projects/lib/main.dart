import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home:Scaffold(
      backgroundColor: Colors.lightBlue[900],
      appBar: AppBar(
        title:const Text("C.V") ,
        centerTitle: true,
       backgroundColor: Colors.lightBlue[700],
      ),
        body:SingleChildScrollView(
        child:Container(

          padding:const EdgeInsets.fromLTRB(30,40,30,0),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
            const Center(
              child: CircleAvatar(
                radius: 60,
                backgroundImage: AssetImage('images/avatar.png')),
            ),

              const SizedBox(

                height: 25,
              ),
              const Divider(
                height: 100,
                color: Colors.black,
              ),
              Text(
                  "NAME:",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlue[200],
                    letterSpacing: 2
              )
              ),
              Text(
                  "Yasmeen Ahmed Mohammed Saleh",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w100,
                    color: Colors.lightBlue[100],

                  )

              ),
              const SizedBox(
                height: 20,
              ),


              Text(
                  "skills:",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlue[200],
                      letterSpacing: 2

                  )
              ),

              Text(
                  textAlign: TextAlign.justify,
           """\nActive listening\nCommunication\nComputer skills\nCustomer service
              """,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w100,
          color: Colors.lightBlue[100],

        )
              ),
              const SizedBox(
                height: 20,
              ),

              Text(
                  "QUALIFICATIONS:",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlue[200],
                      letterSpacing: 2

                  )
              ),

                Text(
                    textAlign: TextAlign.left,


                    """\nStrong, positive attitude\nProject Management skills\nGood communication skill\nUI UX design""",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w100,
                      color: Colors.lightBlue[100],

                    )

    ),

              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  Icon(Icons.email,color: Colors.lightBlue[100] , size: 30,),
                  const SizedBox(width: 10,),
                Text('yasmeegggggggo27.gmail.com',style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold ,color: Colors.lightBlue[100]),)
                ],
              ),
              const SizedBox(
                height: 20,
              ), Row(
                children: [
                  Icon(Icons.phone,color: Colors.lightBlue[100] , size: 30,),
                  const SizedBox(width: 10,),
                  Text('7777777777',style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold ,color: Colors.lightBlue[100]),)
                ],
              ), const SizedBox(
                height: 20,
              ), Row(
        children: [
        Icon(Icons.account_box,color: Colors.lightBlue[100] , size: 30,),
      const SizedBox(width: 10,),
      Text('linkedin account:yasmeen',style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold ,color: Colors.lightBlue[100]),)
      ],
    )


            ],
          ),
        )
    )
  )
  )
  );

}


